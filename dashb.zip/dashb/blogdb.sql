-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2021 at 10:12 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `email` char(80) NOT NULL,
  `password` char(50) NOT NULL,
  `phone` char(11) NOT NULL,
  `address` char(100) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `phone`, `address`, `role_id`) VALUES
(6, 'mariam', 'mariam6574@gmail.com', 'ed0b619a97ddcbf3bdc41bb32abd90ab', '01543647690', 'cairo egypt', 2),
(7, 'sara sobhy', 'sara@gmail.com', '5dcb20c3609a45c070cf5bf6e63e395a', '01234567890', 'assuit egypt', 2),
(8, 'sarah', 'sarah1234@gmail.com', 'cd3a77622ef59e64711dfd05f1a263a6', '01002030405', 'any placesss', 1),
(9, 'sarah', 'asdasd@gmail.com', 'a3dcb4d229de6fde0db5686dee47145d', '01298765432', 'asdasdasdasdasdasd', 1),
(13, 'Abel Farmer', 'Abel_Farmer@mailinator.com', '4a88d1e8b40e8448b79cb6d4a3e999c7', '01240977656', 'asd fgghn gbfgfg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `articales`
--

CREATE TABLE `articales` (
  `id` int(11) NOT NULL,
  `title` char(80) NOT NULL,
  `descrip` varchar(10000) NOT NULL,
  `added_by` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `image` char(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articales`
--

INSERT INTO `articales` (`id`, `title`, `descrip`, `added_by`, `cat_id`, `image`) VALUES
(1, 'software', 'ARTICLE\r\nWe have provided various types of articles on different topics (such as general articles, articles on social issues, etc) for your children (studying in classes 4, 5, 6, 7, 8, 9, 10, 11 or 12). Such type of articles can be very helpful for teachers to make their students actively participating in the extra-curricular activities like article writing, debate, etc.\r\n\r\n\r\n \r\nArticles are written in very simple and easy language using very easy words. Articles are good source of knowledge for students or people working on related projects. Such articles will help and motivate students to get more knowledge about different topics. We have provided below very unique and interesting general topics articles which are generally assigned to students in the school.\r\n\r\nArticle Topics\r\n\r\nFollowing are different types of article topics for the students which are categorized in sections so that you can easily choose the topic as per your need and requirement.\r\n\r\n \r\n\r\nSwachh Bharat Abhiyan – in Gramin/Rural Areas\r\n\r\nSwachh Bharat Abhiyan: in Urban Areas\r\n\r\nSwachh Bharat Abhiyan: An Initiative for Pollution/Garbage Free Diwali this Year\r\n\r\nSwachh Bharat Abhiyan: Success Stories of Few Villages/Cities\r\n\r\nSwachh Bharat Abhiyan: Activities, Challenges, Success\r\n\r\nSwachh Bharat Mission: Swachh Vidyalaya Abhiyan\r\n\r\nSwachh Bharat Abhiyan: Need and Importance\r\n\r\nSwachh Bharat Abhiyan: Brand Ambassadors\r\n\r\nSwachh Bharat Abhiyan: Single Use Plastic Ban\r\n\r\nPros and Cons of Privatization of Indian Railway\r\n\r\nPros and Cons of Privatization of BALCO\r\n\r\nPros and Cons of Privatization of PSU\r\n\r\nPros and Cons of Privatization of Banks\r\n\r\nPros and Cons of Privatization of VSNL\r\n\r\nPros and Cons of Privatization\r\n\r\nAchievements of India after Indepe', 9, 2, '5747212061624491100.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `articalescategory`
--

CREATE TABLE `articalescategory` (
  `id` int(11) NOT NULL,
  `title` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articalescategory`
--

INSERT INTO `articalescategory` (`id`, `title`) VALUES
(1, 'IS'),
(2, 'CS'),
(3, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `building`
--

CREATE TABLE `building` (
  `buildingId` int(11) NOT NULL,
  `buildingName` varchar(50) NOT NULL,
  `rateNumber` int(5) NOT NULL,
  `location` varchar(100) NOT NULL,
  `category` char(100) NOT NULL,
  `buildingImg` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `building`
--

INSERT INTO `building` (`buildingId`, `buildingName`, `rateNumber`, `location`, `category`, `buildingImg`) VALUES
(1, 'company of sites', 4, 'Cairo', 'websites', NULL),
(2, 'company of cloths', 3, 'Alex', 'shopping', NULL),
(3, 'Dell', 4, 'Assuit', 'Electronics', NULL),
(4, 'pizza', 5, 'Asswan', 'food', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `reviewID` int(11) NOT NULL,
  `buildingID` int(100) NOT NULL,
  `userID` int(100) NOT NULL,
  `review` varchar(500) NOT NULL,
  `reviewDate` date NOT NULL,
  `reviewTime` time NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviewID`, `buildingID`, `userID`, `review`, `reviewDate`, `reviewTime`, `rating`) VALUES
(1, 1, 1, 'good site to visit ', '2021-06-25', '03:19:23', 5),
(2, 2, 3, 'very good material', '2021-06-24', '03:22:23', 4),
(3, 3, 2, 'high tec and very modern electronics ', '2021-06-09', '03:19:23', 4),
(4, 4, 5, 'soooo tasty  ', '2021-06-07', '03:22:23', 5);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `title` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`) VALUES
(1, 'admin'),
(2, 'super admin'),
(6, 'super user'),
(8, 'normal user one'),
(9, 'super admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `fName` varchar(100) NOT NULL,
  `lName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phoneNumber` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` text NOT NULL,
  `bithday` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `fName`, `lName`, `email`, `phoneNumber`, `password`, `gender`, `bithday`) VALUES
(1, 'sarah', 'sobhy', 'sara.sobhy300@gmail.com', '01296847340', '98eae7ae7cae940268507739f476e036', 'female', '2012-03-14'),
(2, 'Leslie Christian', 'Mercado', 'tuwoji_tuwoji@mailinator.com', '01297869605', '7280afc0a6b50b38519e8f0521bb39cf', 'male', '2012-03-14'),
(3, 'Wilma Wolf', 'Conley', 'Wilma_Wolf@mailinator.com', '01294837590', '6bbf0b632b2ef61b8d1cd8f6249500b8', 'male', '2012-03-14'),
(4, 'Candice Melton', 'Cook', 'Candice_Melton@mailinator.com', '07969594838', '6710c8ab915aa249f7dc58fb0eecd27e', 'female', '1994-04-21'),
(5, 'Cora Fischer', 'Mason', 'Cora_Fischer@mailinator.com', '47434567890', '71f26b346ba81333a8d9543e7a946422', 'male', '2009-06-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `articales`
--
ALTER TABLE `articales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addedBy` (`added_by`),
  ADD KEY `articalesCat` (`cat_id`);

--
-- Indexes for table `articalescategory`
--
ALTER TABLE `articalescategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `building`
--
ALTER TABLE `building`
  ADD PRIMARY KEY (`buildingId`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`reviewID`),
  ADD KEY `reviewAndUser` (`userID`),
  ADD KEY `reviewAndBuilding` (`buildingID`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `articales`
--
ALTER TABLE `articales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `articalescategory`
--
ALTER TABLE `articalescategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `building`
--
ALTER TABLE `building`
  MODIFY `buildingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `reviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `roleRelation` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `articales`
--
ALTER TABLE `articales`
  ADD CONSTRAINT `addedBy` FOREIGN KEY (`added_by`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `articalesCat` FOREIGN KEY (`cat_id`) REFERENCES `articalescategory` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviewAndBuilding` FOREIGN KEY (`buildingID`) REFERENCES `building` (`buildingId`),
  ADD CONSTRAINT `reviewAndUser` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
