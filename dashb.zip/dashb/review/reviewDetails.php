<?php 
 include './operations/fun.php';
 include './operations/connections.php';
 include 'head.php';
 include 'myNav.php';
 include 'mySideNav.php';
 include 'model.php';


 
 $errors  = array();
 $message = ""; 


 if($_SERVER['REQUEST_METHOD'] == "GET"){
  
  if(isset($_GET['id'])){

      $id = filter_var($_GET['id'],FILTER_SANITIZE_NUMBER_INT);

      if(filter_var($id,FILTER_VALIDATE_INT)){
        
        $sql= "select reviews.* , building.* from reviews join building on reviews.buildingID =".$id;
          $op  = mysqli_query($con,$sql);
          $count = mysqli_num_rows($op);
  
       


    if($count == 0){
      $message = "Invalid Id";  
     // $errors['id'] = 1 ;

    }


  
      }else{
          $message = "InValid id value";
          //$erros['id'] = 1 ;
      }


  }else{
    $message     = "Id Not Founded";  
    //$erros['id'] = 1 ;
  }

  


    if(count($errors) > 0 ){
        $_SESSION['message'] = $message;
        header("Location: Home.php");
    }else{
        $data = mysqli_fetch_assoc($op);
    }




 }


?>

  <body> 
  <div class="container">     
<?php
          
   if(isset($_SESSION['error_message']) ){

      foreach($_SESSION['error_message'] as $key => $value){
          echo '* '.$value;
      }
   }

 ?>                       


<table class="table">
  <thead>
    <tr>
      <th scope="col">review</th>
      <th scope="col">Date</th>
      <th scope="col">Building Name</th>
      <th scope="col">Rate Number</th>
      <th scope="col">location</th>
      <th scope="col">Category</th>
       
    </tr>
  </thead>
  <tbody>
  <?php 
  if($count>=1){
  while ($data = mysqli_fetch_assoc($op)){
  ?>
    <tr>
      
      <td><?php  echo $data['review']; ?></td>
      <td><?php  echo $data['reviewDate']; ?></td>
      <td><?php  echo $data['buildingName']; ?></td>
      <td><?php  echo $data['rating']; ?></td>
      <td><?php  echo $data['location']; ?></td>
      <td><?php  echo $data['category']; ?></td>
     
   </tr>
    
    </tr>
   <?php } }?> 

  </tbody>
</table>
</div>
<?php 
include 'foot.php';
?>
</body>
</html>