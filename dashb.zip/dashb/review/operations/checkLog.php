
<?php 


if(!isset($_SESSION['userId'])){


    header("Location:".url('app.php'));
}



?>