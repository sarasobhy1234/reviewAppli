<?php 
session_start();
 function Clean($input)
 {
     $input=trim($input);
     $input=htmlspecialchars($input);
     $input=stripcslashes($input);
     return $input;
 }


 function url($url)
 {
   return   "http://".$_SERVER['HTTP_HOST']."/dashb/review/".$url;
}

?>