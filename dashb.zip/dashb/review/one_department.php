<!DOCTYPE html>
<html>
<?php 
include 'head.php';
?>
<title>one</title>
 <body>
 <?php 
   include 'myNav.php';
   ?>
    <div class="container">

       <!-- 
        <div id="myCarousel" class="carousel slide  " style="width: 500px; margin-left: 400px;" data-ride="carousel">
            Indicators 
            <ol class="carousel-indicators" >
              <li  data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
              <li data-target="#myCarousel" data-slide-to="3"></li>
              <li data-target="#myCarousel" data-slide-to="4"></li>
              <li data-target="#myCarousel" data-slide-to="5"></li>
              <li data-target="#myCarousel" data-slide-to="6"></li>
              <li data-target="#myCarousel" data-slide-to="7"></li>
              <li data-target="#myCarousel" data-slide-to="8"></li>
            </ol>
            <div class="carousel-inner" >
              <div class="carousel-item active">
                <img src="img/hotel.jpg"   alt="hotel" style="width:500px; height: 500px;">
              </div>
              <div class="carousel-item">
                <img src="img/company.jpg"   alt="company" style="width:500px; height: 500px;">
               
              </div>
              <div class="carousel-item">
                <img src="img/tec1.jpg"   alt="Technology" style="width:500px; height: 500px;">
              </div>
              <div class="carousel-item">
                <img src="img/repair1.jpg" alt="Repair Shops" style="width:500px; height: 500px;">
        
              </div>
              <div class="carousel-item">
                <img src="img/res1.jpg" alt="Restusants" style="width:500px; height: 500px;">
            
              </div>
              <div class="carousel-item">
                <img src="img/web.jpg" alt="Websites" style="width:500px; height: 500px;">
        
              </div>
              <div class="carousel-item">
                <img src="img/company.jpg" alt="company" style="width:500px; height: 500px;">
              </div>
              <div class="carousel-item">
                <img src="img/shopping.jpg" alt="shopping" style="width:500px; height: 500px;">
              </div>
              <div class="carousel-item">
                <img src="img/baby1.jpg" alt="baby" style="width:500px; height: 500px;">
                
              </div>
          
            </div>
        
             Left and right controls
            <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </a>
              <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
          </div> -->



<br> <br>
        <label style="background-color: rgb(159, 120, 196); font-size: x-large; border-radius: 5px; padding: 10px;">Department</label>
        <br> <br>
        <form class="form  row">
            <div class="input-group col-8 ">
                <input type="text" name="" id="" class="form-control" placeholder="Search">
            </div>
            <div class="input-group-append col-4">
                <button type="submit" class="btn btn-danger">
                    <i class="fa fa-search"> Search</i>
                </button>
            </div>
        </form>
        <br> <br> <br> 
     
            
 <?php 
include 'model.php';
?>
           
          
          <form class="form" method="" action="">

            <div class="row">
                <div class="dropdown col-6">
                    <a class=" dropdown-toggle" data-toggle="dropdown" href="#">Name</a>
                    <div class="dropdown-menu" >
                        <a href="#" class="dropdown-item" onclick="document.getElementById('name1').innerHTML= 'place name 1'" > place name 1</a>
                        <a href="#"class="dropdown-item"   onclick="document.getElementById('name1').innerHTML= ' place name 2'" >place name 2</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('name1').innerHTML= 'place name 3'"> place name 3</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('name1').innerHTML= 'place name 4'"> place name 4</a>
                        <a href="#" class="dropdown-item" onclick="document.getElementById('name1').innerHTML= 'place name 5'"> place name 5</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('name1').innerHTML= 'place name 6'"> place name 6</a>
                        <a href="#"class="dropdown-item" onclick="document.getElementById('name1').innerHTML= 'place name 7'" > place name 7</a>
                        <a href="#"class="dropdown-item" onclick="document.getElementById('name1').innerHTML= 'place name 8'" > place name 8</a>
                        <a href="#"class="dropdown-item"   data-toggle="modal" data-target="#form" >add anther place </a>
                            
                    </div>
                    </div>
                    <div class="dropdown col-6">
                        <a class=" dropdown-toggle" data-toggle="dropdown" href="#">City</a>
                        <div class="dropdown-menu ">
                            <a href="#" class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Cairo'"  >Cairo</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Alex'"  >Alex</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Giza'" >Giza</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Fyoum'" >Fyoum</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'minia'" >minia</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Assuit'" >Assuit</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Qina'" >Qina</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Sohag'" >Sohag</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Loxor'" >Loxor</a>
                            <a href="#"class="dropdown-item"  onclick="document.getElementById('city1').innerHTML= 'Aswan'" >Aswan</a>
                            <a href="#"class="dropdown-item"  data-toggle="modal" data-target="#form"  >add anther city</a>
                            
                        </div>
                        </div>
                    </div>
                    <br>  <br> 
                    <div class="row " >
                        <label class="col-6" id="name1"  style="color: seagreen; font-size: large;" ></label>
                        <label class="col-6" id="city1" style="color: red; font-size: large;"></label>
   
                        <br>  <br> 

                        
                        <div class="form">
           <div class="col-6"><b>Choose Your Rate</b></div>
          <br>  
          &nbsp;  &nbsp; <input type="radio" name="rate_number" id="rate_number5" value="5" ><b class="text-success"> Perfect</b>
          &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp; 
   <input type="radio" name="rate_number" id="rate_number4" value="4"> <b class="text-primary">Very Good</b> 
   &nbsp;  &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp;
    <input type="radio" name="rate_number" id="rate_number3" value="3"> <b class="text-info"> Good</b>
   &nbsp;  &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp;
    <input type="radio" name="rate_number" id="rate_number2" value="2"> <b class="text-warning"> Not Bad</b>
   &nbsp;  &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp;
   <input type="radio" name="rate_number" id="rate_number1" value="1"> <b class="text-danger"> Bad</b>
   <br>  <br>     
</div>
                    </div>
            <div class="input-group">
              <textarea  name="txt1"  id="txt1" class="form-control" placeholder="write your opinion"></textarea>
                    </div>
                </div>
                    <br>
                        <div class="star">
                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                         <span class="heading">User Rating</span>
                        <span class="fa fa-star checked" id="1"></span>
                        <span class="fa fa-star checked" id="2"></span>
                        <span class="fa fa-star checked" id="3"></span>
                        <span class="fa fa-star checked" id="4"></span>
                        <span class="fa fa-star"id="5"></span>
                    </div>
                    <br>
            <div class="input-group-append">
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp;&nbsp;&nbsp;
                <input type="button" class="btn btn-primary" id="post" value="post">
                
            </div>
        </form>
        <script>
            $(function(){
            $("#post").click(function(){
                var x;
                x=$("#txt1").val();
                alert(x);
            $("#add_review").prepend('<li>'+x+'</li>');
           alert(x);
            $("#txt1").val("");
            });
                });
        </script> 


        <div>
         
          <ul id="add_review">

            <li>High Rate</li>
           
          </ul>
           <ul id="high_rated">
            <li>High Rated</li>
            <li>High Rate</li>
           
          </ul>
        </div>
        <?php 
include 'mySideNav.php';
?>
           </div>
    <br> <br>
    <?php 
    include 'foot.php';
   ?>
 </body>

</html>







