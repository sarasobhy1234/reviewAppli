<!DOCTYPE html>
<html>

<head>
    <link rel="icon" href="img/like.jpg" sizes="16x16">

    <title>Review App</title>
    <link rel="stylesheet" href="style1.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body {
  background-image: url('img/rev.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}
.zoom {
  padding: 50px;
  transition: transform .2s; /* Animation */
  
  margin: 0 auto;
}


.center {
  margin: 0;
  position: absolute;
  top: 36%;
  left: 24%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}

.zoom:hover {
  transform: scale(1.5); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

</style>
</head>

<div class="btn-group center" role="group" aria-label="Basic mixed styles example">
 <a href="register.php"> <button type="button" class="btn btn-success zoom">Register</button></a>
 <a href="login.php"> <button type="button" class="btn btn-primary zoom">Login</button></a>
</div>
                 
</body>
</html>
