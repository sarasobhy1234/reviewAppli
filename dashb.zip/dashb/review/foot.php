<footer class=" text-light fixed-bottom"  >
        <div class="row m-1" style="background-color: indigo;">
            <div class="col-md-6 ">
                Copyright &copy; 2020 Reviews.com
            </div>
            <div class="col-md-6  text-right ">
                <a href="#" class="text-light"><i class="fa fa-facebook"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> 	<i class="fa fa-instagram"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> 	<i class="fa fa-twitter"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> 	<i class="fa fa-youtube-square"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> 	<i class="fa fa-pinterest-square"></i></a>
            </div>
        </div>

    </footer>