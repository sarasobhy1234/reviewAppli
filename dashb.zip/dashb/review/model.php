

  <div class="modal fade" id="fo" style="border-radius: 20px;">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Write Your Review</h4>
          <button type="button" class="close" data-dismiss="modal">×</button>
        </div>
        <!-- Modal body -->
        <div class="modal-body ">
            <div class="row">
            <div class="dropdown col-6">
                <a class=" dropdown-toggle" data-toggle="dropdown" href="#">Department</a>
                <div class="dropdown-menu" >
                    <a href="#" class="dropdown-item" onclick="document.getElementById('dep').innerHTML= 'Restusants'" > Restusants</a>
                    <a href="#"class="dropdown-item"   onclick="document.getElementById('dep').innerHTML= 'Repair Shops'" >Repair Shops</a>
                    <a href="#"class="dropdown-item"  onclick="document.getElementById('dep').innerHTML= 'Websites'">Websites</a>
                    <a href="#"class="dropdown-item"  onclick="document.getElementById('dep').innerHTML= 'Hoteles'">Hoteles</a>
                    <a href="#" class="dropdown-item" onclick="document.getElementById('dep').innerHTML= 'Companies'">Companies</a>
                    <a href="#"class="dropdown-item"  onclick="document.getElementById('dep').innerHTML= 'Shopping'">Shopping</a>
                    <a href="#"class="dropdown-item" onclick="document.getElementById('dep').innerHTML= 'Baby Products'" >Baby Products</a>
                    <a href="#"class="dropdown-item" onclick="document.getElementById('dep').innerHTML= 'Technology & Electronices'" >Technology & Electronices</a>
                </div>
                </div>
                <div class="dropdown col-6">
                    <a class=" dropdown-toggle" data-toggle="dropdown" href="#">City</a>
                    <div class="dropdown-menu ">
                        <a href="#" class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Cairo'"  >Cairo</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Alex'"  >Alex</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Giza'" >Giza</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Fyoum'" >Fyoum</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'minia'" >minia</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Assuit'" >Assuit</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Qina'" >Qina</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Sohag'" >Sohag</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Loxor'" >Loxor</a>
                        <a href="#"class="dropdown-item"  onclick="document.getElementById('city').innerHTML= 'Aswan'" >Aswan</a>
                        
                    </div>
                    </div>
                </div>
                <br> <br>
                    <div class="row " >
                        <label class="col-6" id="dep"  style="color: seagreen; font-size: large;" ></label>
                        <label class="col-6" id="city" style="color: red; font-size: large;"></label>

                        <br>  <br> <br>
                        <div class="form">
   <label class="col-6">Type The Place Name</label><input type="text" class="col-6" >
   
   
<label class="col-6">Type Here your Review</label><input type="text" class="col-6" >
 </div>
                    </div>

                    <div class="form">
           <div class="col-6"><b>Choose Your Rate</b></div>
          <br>  
          &nbsp;  &nbsp; <input type="radio" name="rate_number" id="rate_number5" value="5" ><b class="text-success"> Perfect</b>
          &nbsp;   &nbsp;  &nbsp;  &nbsp; 
   <input type="radio" name="rate_number" id="rate_number4" value="4"> <b class="text-primary">Very Good</b> 
   &nbsp;  &nbsp;   &nbsp;  &nbsp;
    <input type="radio" name="rate_number" id="rate_number3" value="3"> <b class="text-info"> Good</b>
   &nbsp;  &nbsp;   &nbsp;  &nbsp;
    <input type="radio" name="rate_number" id="rate_number2" value="2"> <b class="text-warning"> Not Bad</b>
   &nbsp;  &nbsp;   &nbsp;  &nbsp;
   <input type="radio" name="rate_number" id="rate_number1" value="1"> <b class="text-danger"> Bad</b>
   <br>  <br>     
</div>
                    <br> <br>  <br> <br>


        </div>   
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger" data-dismiss="modal" onclick="alert('Thank you for your time !')">Submite</button>
        </div>
        
      </div>
    </div>
  </div>
  
  