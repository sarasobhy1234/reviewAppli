<?php 

include './operations/fun.php';
include './operations/connections.php';




if ($_SERVER['REQUEST_METHOD'] == "POST" )
{
$fname= Clean($_POST['fname']);
$lname= Clean($_POST['lname']);
$email= Clean( $_POST['email']);
$phone= Clean($_POST['phone']); //
$bDate= Clean($_POST['birth']);//
$password= Clean($_POST['password']);
$rePassword= Clean($_POST['rePassword']);
$gender= Clean($_POST['gender']);


$errormsg=array();

// fname validate 
  if( empty($fname) )
  {
    
    $errormsg['fname'] = "Name Field Required !";
  }
  else 
  {
    if(strlen($fname)<3)
    {
        $errormsg['fname'] = "Name Must Be > 3 Char !";
        
    }
    elseif(! preg_match("/^[a-zA-Z-' ]*$/",$fname))
    {
        $errormsg['fname'] = "Only Char Allowed !";
     
    }
  }


  // lname validate 
  if( empty($lname) )
  {
    
    $errormsg['lname'] = "Name Field Required !";
  }
  else 
  {
    if(strlen($lname)<3)
    {
        $errormsg['lname'] = "Name Must Be > 3 Char !";
        
    }
    elseif(! preg_match("/^[a-zA-Z-' ]*$/",$lname))
    {
        $errormsg['lname'] = "Only Char Allowed !";
     
    }
  }




  // validate email

  if( empty($email) )
{
    $errormsg['email']= "Email field is required";
}
else 
{
    if(filter_var($email,FILTER_VALIDATE_EMAIL)==false)
    {
        $errormsg['email'] ="Invaild email";
    }
   
}

// validate password
if (empty($password))
{
    $errormsg['password']= "password feild requid";
}
else
 {
    if(strlen($password)<8)
   {
    $errormsg['password'] ="password must be >8 char !";
   }
  
}


// validate repassword
if (empty($rePassword))
{
    $errormsg['repassword']= "password feild requid";
}
else
 {
    if(strlen($rePassword)<8)
   {
    $errormsg['repassword'] ="password must be >8 char !";
   }
  
}

if ($password != $rePassword) {

    $errormsg['repassword'] ="passwords not matched";
}
 

// validate birthday date

$startDate = ( "1980-01-01");
$endDate = ("2010-01-01");
if(empty($bDate)){
    $errors['bDate'] = "Empty Field";
}elseif($bDate<$startDate || $bDate>$endDate){
    $errors['bDate'] = "Not Allowed for you to use this site";

}






 


// validate phone number 
if(empty($phone)){
    $errors['phone'] = "Empty Field";
}elseif(strlen($phone) != 11 ){
    $errors['phone'] = "Length must be 11";

}else{

    $patternNum = "/^\d{11}$/";

    if(!preg_match($patternNum,$phone)){
        $errors['phone'] = "Invalid Input";

    }
}

    if (count($errormsg)>0)
    {
        foreach($errormsg as $key => $data)
        {
            echo $key . ">>>>" .$data .'<br>';
        }
    }
    
  else { 
     
    
    $sql= "select * from users where email = '$email'";
    $op = mysqli_query($con,$sql);
    $count = mysqli_num_rows($op);

    if($count>0)
    {
      echo "You Have An Account In Our Site , Please Login ";

    }
    else 
    {
      $password = md5($password);
      $sql="insert into `users`( fName, lName,email, phoneNumber, password, gender,bithday) values
                               ('$fname','$lname','$email','$phone','$password','$gender','$bDate')";
      $op = mysqli_query($con,$sql);
  
      if($op)
      {
        echo "inserted";
        header("location: Home.php");
      }
      else 
      {
        echo "error Retry ";
      }
    }
  }
}//end of main if

?>



<!DOCTYPE html>
<html>

<head>
    <link rel="icon" href="img/like.jpg" sizes="16x16">

    <title>Register</title>
    <link rel="stylesheet" href="style1.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <nav class="navbar  navbar-expand-md sticky-top" style="background-color: black;">
        <a href="#" class="navbar-brand">Reviews.com</a>
        
        <div id="nav" class="collapse navbar-collapse">
            <div class="navbar-nav ml-auto">
                <a href="login.php" class="nav-item nav-link">Login</a>

            </div>
        </div>

    </nav> <br><br> <br>
    <div class="container">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
            <h3>Register here :)</h3>
            <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
            
                   <div class="form-group">
                        <label for="fname">Frist Name</label>
                        <input type="text" name="fname" id="fname" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="lname">Last Name</label>
                        <input type="text" name="lname" id="lname" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Email"> Email</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="number" name="phone" id="phone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="birth">Birth Date</label>
                        <input type="date" name="birth" id="birth" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Re_password">Re_password</label>
                        <input type="password" name="rePassword" id="Re_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender &nbsp; </label>
                        <input type="radio" style="border-radius: 5px; " name="gender" value="male" selected> Male
                        &nbsp; <input type="radio" style="border-radius: 5px;" name="gender" value="female"> Female <br>
                        <br>
                    </div>
                    <input type="submit" class="btn btn-light btn-lg ">
                    <button class="btn btn-danger btn-lg">Singup With Gmail</button>
                    <button class="btn btn-primary btn-lg">Singup With Facebook</button>
                    <br>
                    <br>
                </form>
            </div>
            <div class="col-3"></div>
        </div>



       


    </div>
    <footer class=" text-light">
        <div class="row m-1" style="background-color: indigo;">

            <div class="col-md-6 fixed-bottom ">
                Copyright &copy; 2020 Reviews.com
            </div>
            <div class="col-md-6  text-right ">
                <a href="#" class="text-light"><i class="fa fa-facebook"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> <i class="fa fa-instagram"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> <i class="fa fa-twitter"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> <i class="fa fa-youtube-square"></i></a>
                <span class="text-muted">|</span>
                <a href="#" class="text-light"> <i class="fa fa-pinterest-square"></i></a>

            </div>
        </div>
    </footer>
</body>

</html>