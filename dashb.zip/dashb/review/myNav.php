

<nav class="navbar  navbar-expand-md sticky-top" style="background-color: black;">
        <a href="Home.php" class="navbar-brand">Reviews.com</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#nav" style="background-color: blue;">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div id="nav" class="collapse navbar-collapse">
            <div class="navbar-nav ">
                <a href="Home.php" class="nav-item nav-link active"><i class="fa fa-home"></i> Home</a>
                <a href="#" class="nav-item nav-link" data-toggle="modal" data-target="#fo">
                    <i class="fa fa-pencil"></i> Quick Review</a>
                <a href="contactUs.php" class="nav-item nav-link"><i class="fa fa-phone"></i> Contact</a>
                <a href="aboutUs.php" class="nav-item nav-link"><i class="fa fa-question-circle"></i> About</a>

            </div>
            <form class="form-inline ml-auto" action="" method="post"  >
                <div class="input-group">
                    <input type="text" name="search" id="" class="form-control" placeholder="Search">
                </div>
                <div class="input-group-append">
                    <button type="submit" class="btn btn-secondary">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </form>
            <div class="navbar-nav ml-auto">
                <a href="login.php" class="nav-item nav-link">Logout</a>

            </div>
        </div>

    </nav>




    

