<!DOCTYPE html>
<html>
<?php 
include 'head.php';
?>
   <title>About Us</title>
 <body>
   <?php 
   include 'myNav.php';
   ?>
    <div class="container">
        <br><br>
        <div   id="jumb" style="background-color: rgb(139, 202, 218);">
          <div class="row">
            <div class="col-4">
                <img src="img/about.jpg " style="height: 600px; width: 350px;"> </div>
            <div class="col-4">
              <br> <br> <br><br> <br> <br><br> <br>
                <h5 >  "There are many things around us , we need to know mere about it 
                   Food , Website , Fashion , Electronices , Softwere and so many of those.
                In our site you can find real experiences from some people how test or use something. 
            And you also can write your Review and<a href="register.php"> join </a> our communty and help people to know 
        the best thing , our site will take rewiews and show it in our wall
         to help others, hope you find what you are looking for !  "</h5>
            </div>
            <div class="col-4">
                <img src="img/thank.jpg" style="height: 600px; width: 350px;">   
            </div>
          </div>
          
        </div>
        
<?php 
include 'mySideNav.php';
?>
    

    <?php 
include 'model.php';
?>
    



           </div>
    <br> <br>
   <?php 
    include 'foot.php';
   ?>
 </body>

</html>







