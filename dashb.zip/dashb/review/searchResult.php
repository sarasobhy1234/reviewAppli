







<?php 
include 'head.php';
include 'myNav.php';
include 'mySideNav.php';
include 'model.php';

if ($_SERVER['REQUEST_METHOD'] == "POST" )
 {
  $input= $_POST['search'];
  $input=trim($input);
    $input=htmlspecialchars($input);
    $input=stripcslashes($input);

 // name validate 
  if( empty($input) )
   {
    
    echo " Field Required !";
   }
 
    elseif(! preg_match("/^[a-zA-Z-' ]*$/",$input))
    {
        $errormsg['search'] = "Only Char Allowed !";
     
    }
 else 
 {
  $sql= "select * FROM reviews where review like %$input%" ;
   
   //if exsist(SELECT * FROM reviews where review like %$input%)
   // $sql= "select * from users where name like '%$input%'";
    //{
    $sql= "select reviews.* , building.* from reviews join building where reviews.buildingID = building.buildingId";
    $op = mysqli_query($con,$sql);
     $count=mysqli_num_rows($op);
     if ($count>0)
     {
      $sqll= "select reviews.* , building.* from reviews join building on reviews.buildingID = building.buildingId";
      $opp = mysqli_query($con,$sqll);
      $count1=mysqli_num_rows($opp);
    }
    
    }
    
  } // end of main if 

?>




<table class="table">
  <caption><h1>List of products</h1></caption>
  <thead>
    <tr>
      <th scope="col">review</th>
      <th scope="col">Data</th>
      <th scope="col">Building Name</th>
      <th scope="col">Rate Number</th>
      <th scope="col">location</th>
      <!--<th scope="col">Image</th>-->
       
    </tr>
  </thead>
  <tbody>
  <?php 
  if($count1>=1){
  while($data = mysqli_fetch_assoc($opp)) {
  ?>
    <tr>
      
      <td><?php  echo $data['review']; ?></td>
      <td><?php  echo $data['reviewDate']; ?></td>
      <td><?php  echo $data['buildingName']; ?></td>
      <td><?php  echo $data['rateNumber']; ?></td>
      <td><?php  echo $data['location']; ?></td>
      <td><?php // echo $data['buildingImg']; ?></td>
     
   </tr>
    
    </tr>
   <?php } }?> 

  </tbody>
</table>
<?php 
include 'foot.php';
?>

