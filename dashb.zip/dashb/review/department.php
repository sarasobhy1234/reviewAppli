<!DOCTYPE html>
<html>
<?php 
include 'head.php';
?>
   <title>Departments </title>

 <body>
 <?php 
   include 'myNav.php';
   ?>
    <div class="container">
       
          
        <div class="card-columns">
            <div class="card" >
              <div class="card-body text-center">
                <img class="card-img-top" src="img/res1.jpg" alt="Card image" style="height: 400px;" >
                <p class="card-text"><a href="one_department.html"style="text-decoration: none; font-size: 20px;color: black;">Restusants</a></p>
                
                      </div>
            </div>
            <div class="card ">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/repair1.jpg" alt="Card image" style="height: 400px;" >
              
                <p class="card-text"><a href="one_department.php" 
                    style="text-decoration: none; font-size: 20px;color:black;">Repair Shops</a></p>
              </div>
            </div>
            <div class="card">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/web2.jpg" alt="Card image" style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php"
                 style="text-decoration: none; font-size: 20px;color:black;">Websites</a></p>
              </div>
            </div>
            <div class="card ">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/hotel.jpg" alt="Card image"style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php" style="text-decoration: none; font-size: 20px;color:black;">Hoteles</a></p>
              </div>
            </div>  
            <div class="card ">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/company.jpg" alt="Card image"style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php"
             style="text-decoration: none; font-size: 20px;color:black;">Companies</a></p>
              </div>
            </div>  
            <div class="card" >
              <div class="card-body text-center">
                <img class="card-img-top" src="img/shopping.jpg" alt="Card image"style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php" 
                style="text-decoration: none; font-size: 20px;color: black;">Shopping</a></p>
              </div>
            </div>  
            <div class="card">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/baby1.jpg" alt="Card image"style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php"
                style="text-decoration: none; font-size: 20px;color: black;">Baby Products</a></p>
              </div>
            </div>  
            <div class="card">
              <div class="card-body text-center">
                <img class="card-img-top" src="img/tec4.jpg" alt="Card image"style="height: 400px;">
              
                <p class="card-text"><a href="one_department.php" 
            style="text-decoration: none; font-size: 20px;color:black;">Technology & Electronices</a></p>
              </div>
            </div>  
          </div>
        

 <?php 
include 'model.php';
?>
    
    
           </div>
    <br> <br>
    <?php 
    include 'foot.php';
   ?>
 </body>

</html>







