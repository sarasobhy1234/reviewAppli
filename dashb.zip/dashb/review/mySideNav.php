<div id="mySidenav" class="sidenav">
    <a href="one_department.php" id="a">Restusants</a>
    <a href="one_department.php" id="b">Repair Shops</a>
    <a href="one_department.php" id="c">Websites</a>
    <a href="one_department.php" id="d">Hoteles</a>
    <a href="one_department.php" id="e">Companies</a>
    <a href="one_department.php" id="f">Shopping</a>
    <a href="one_department.php" id="g">Baby Products</a>
    <a href="one_department.php" id="h">Technology & Electronices </a>
  </div>