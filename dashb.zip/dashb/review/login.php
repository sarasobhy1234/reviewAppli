<?php 

include './operations/fun.php';
include './operations/connections.php';

if ($_SERVER['REQUEST_METHOD'] == "POST" )
{
$password= Clean($_POST['password']);
$email= Clean( $_POST['email']);
$errormsg=array();



  // validate email

  if( empty($email) )
{
    $errormsg['email']= "Email field is required";
}
else 
{
    if(filter_var($email,FILTER_VALIDATE_EMAIL)==false)
    {
        $errormsg['email'] ="Invaild email";
    }
   
}

// validate password
if (empty($password))
{
    $errormsg['password']= "password feild requid";
}
else
 {
    if(strlen($password)<8)
   {
    $errormsg['password'] ="Nmae must be >8 char !";
   }
  
}



    if (count($errormsg)>0)
    {
        foreach($errormsg as $key => $data)
        {
            echo $key . ">>>>" .$data .'<br>';
        }
    }
    
  else { 
     $password = md5($password);
    $sql= "select * from users where email = '$email' and password = '$password'";
    $op = mysqli_query($con,$sql);
    $count = mysqli_num_rows($op);

    if($count ==1)
    { 
        $data= mysqli_fetch_assoc($op);
        $_SESSION['userId']= $data['id'] ;
        $_SESSION['name']= $data['name'] ;
        header("Location: Home.php");


       //echo "Welcome Here";
    }
    else 
    {
      echo "Your Email or Password not Correct ";
    }
  }
    
    
   }//end of main if



?>



<!DOCTYPE html>
<html>

<head>
    <link rel="icon" href="img/like.jpg" sizes="16x16">

    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="fontawesome-free-5.15.1-web/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <nav class="navbar  navbar-expand-md sticky-top" style="background-color: black;">
        <a href="#" class="navbar-brand">Reviews.com</a>
       

        <div class="navbar-nav ml-auto">
        <a href="register.php" class="nav-item nav-link">Register</a>
            </div>     
    </nav>
    <br>
    <br>
    <br>
    <div class="container">
        <div class="row ">
            <div class="col-3"></div>
             <div class="col-6">
             <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
                    <div class="form-group">
                        <label for="Email"> Email</label>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control">
                    </div>
                    <div> <a href="#">Forget password ?</a> </div>

                    <button class="btn btn-light btn-lg"> Login <i class="fa fa-home"></i></button>
                    <button class="btn btn-danger btn-lg">Login With Gmail</button>
                    <button class="btn btn-primary btn-lg">Login With Facebook</button>
                    <br>
                    <br>
                </form>
            </div>
        </div>



                
    </div>
    <?php 
    include 'foot.php';
    ?>
</body>

</html>
