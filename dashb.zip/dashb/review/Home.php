<?php 
include './operations/fun.php';
include './operations/connections.php';
//include './operations/checkLog.php';

$errormsg=array();
$sql= "select * from building where rateNumber>=4 ";
   $op = mysqli_query($con,$sql);
    $count = mysqli_num_rows($op);


?>

<!DOCTYPE html>
<html>
<?php 
include 'head.php';
?>
<title> Home </title>

<body>

<?php 
   include 'myNav.php';
   ?>
    
    <div class="container">
        <div class="jumbotron" id="jumb">
            <div class="row">
                <div class="col-4">
                    <h3 class="display-4"> "Hope You Find What You Want"</h3>
                    <p class="lead">Enjoy exchanging your experiences</p>
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="department.php" role="button">Start</a>
                    </p>
                </div>
                <div class="col-8">
                    <img src="img/review2.jpg" style="width:700px; height: 450px;">
                </div>
            </div>

        </div>
        
  <?php 
  include 'mySideNav.php';
   ?>
    
    <?php 
     include 'model.php';
    ?>

        
        <div>
            <ul id="high_rated">
            <?php 
  if($count>=1){
  while($data = mysqli_fetch_assoc($op)) {
  ?>
                <li><div><b> Company Name :</b> <?php  echo $data['buildingName']; ?>  </div>
                <div><b> Rate Number :</b><?php echo $data['rateNumber'];?></div>
                <div><b> Location :</b><?php echo $data['location'];?></div>
<br>
                <a href='reviewDetails.php?id=<?php echo $data['buildingId']?>' ><button type="button" class="btn btn-primary">View Details</button></a>
                </li>
             
            </ul>
            <?php } }?> 
        </div>
        <br>
        <h3 id="h1"> when you are confused ,
            you can find in our site real experiences for some of them.
            You can can browes and we hope you can find what you are lookig for ....
        </h3>

    </div>
    <br> <br>
    <?php 
    include 'foot.php';
   ?>
</body>

</html>


