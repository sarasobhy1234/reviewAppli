<!DOCTYPE html>
<html>
<?php 
include 'head.php';
?>
   <title>Contact Us</title>

 <body>
 <?php 
   include 'myNav.php';
   ?>
    <div class="container">
        <div class="jumbotron text-right" id="jumb" style="background-image: url(img/contact.jpg); background-repeat: no-repeat;
         height: 500px; width: 985px; color: blanchedalmond; ">
            <h2 > <i class="fa fa-envelope "></i> Reviews.gmail.com</h2>
         <h2> <i class="fa fa-phone"></i>+02234567434</h2>
         <h2> <i class="fa fa-mobile"></i> +01234567434</h2>
         <br> <br><br><br><br> <br><br><br> <br><br>
         <div class=" text-left text-dark ">
            <a href="#"  style="font-size:33px; color: blueviolet;"><i class="fa fa-facebook"></i></a>
            <span class="text-muted">|</span>
            <a href="#"   style="font-size:33px; color: blueviolet;" ><i class="fa fa-instagram"></i></a>
            <span class="text-muted">|</span>
            <a href="#"  style="font-size:33px; color: blueviolet;  " ><i class="fa fa-twitter"></i></a>
            <span class="text-muted">|</span>
            <a href="#"  style="font-size:33px; color: blueviolet; " ><i class="fa fa-youtube-square"></i></a>
            <span class="text-muted">|</span>
            <a href="#" style="font-size:33px ; color: blueviolet;">
                <i class="fa fa-pinterest-square"></i></a>
        </div>
        </div>
        

  <?php 
include 'mySideNav.php';
?>
    

    <?php 
include 'model.php';
?>
    

           </div>
    <br> <br>
    <?php 
    include 'foot.php';
   ?>
 </body>

</html>







