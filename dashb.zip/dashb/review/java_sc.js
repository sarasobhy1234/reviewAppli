function write()
{
    alert("Thank you for your time !")
}